CREATE VIEW `view_meet_bill` AS
  SELECT
    `a`.`id`                                   AS `id`,
    `a`.`subject`                              AS `subject`,
    (CASE WHEN isnull(`c`.`name`)
      THEN `a`.`host`
     ELSE `c`.`name` END)                      AS `name`,
    `a`.`startTime`                            AS `startTime`,
    `a`.`fee`                                  AS `fee`,
    (CASE WHEN isnull(`b`.`call_time`)
      THEN NULL
     ELSE ceiling((`b`.`call_time` / 60)) END) AS `call_time`,
    `d`.`count`                                AS `count`
  FROM (((`meetsys01`.`record` `a` LEFT JOIN (SELECT
                                                `pp`.`phone` AS `phone`,
                                                `pc`.`name`  AS `name`
                                              FROM (`meetsys01`.`public_phone` `pp`
                                                JOIN `meetsys01`.`public_contacts` `pc`
                                                  ON ((`pp`.`pid` = `pc`.`id`)))) `c`
      ON ((`a`.`host` = `c`.`phone`))) LEFT JOIN (SELECT
                                                    `meetsys01`.`bill`.`rid`            AS `rid`,
                                                    sum(`meetsys01`.`bill`.`call_time`) AS `call_time`
                                                  FROM `meetsys01`.`bill`
                                                  WHERE (`meetsys01`.`bill`.`answer` = 3000)
                                                  GROUP BY `meetsys01`.`bill`.`rid`) `b`
      ON ((`a`.`id` = `b`.`rid`))) JOIN (SELECT
                                           `meetsys01`.`attendee`.`rid` AS `rid`,
                                           count(0)                     AS `count`
                                         FROM `meetsys01`.`attendee`
                                         GROUP BY `meetsys01`.`attendee`.`rid`) `d` ON ((`a`.`id` = `d`.`rid`)))
  WHERE (`a`.`status` = 2)